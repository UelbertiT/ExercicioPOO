/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.funcionario;

/**
 *
 * @author aluno
 */
public class Funcionario {

    public static void main(String[] args) {
        gerente Gerente = new gerente();
        
    }
}
